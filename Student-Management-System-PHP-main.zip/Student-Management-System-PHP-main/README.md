# Student-Management-System-PHP
This is a minor project for Web Tech Laboratory made using PHP and Bootstrap
